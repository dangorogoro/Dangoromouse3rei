var unionIntrStatus__u =
[
    [ "val", "unionIntrStatus__u.html#aba0e2dd9b9ad3126fa51a580cec9a4e4", null ],
    [ "Range", "unionIntrStatus__u.html#a8d9b9df27b88f38a551e1166df56ed56", null ],
    [ "Als", "unionIntrStatus__u.html#a9282d9173fcf7eedb09aeebce729b3e3", null ],
    [ "Error", "unionIntrStatus__u.html#a84372f479a60bc65cd0379c436ce6e7d", null ],
    [ "status", "unionIntrStatus__u.html#a50988f6be53b87c729a7c71014735aa3", null ]
];