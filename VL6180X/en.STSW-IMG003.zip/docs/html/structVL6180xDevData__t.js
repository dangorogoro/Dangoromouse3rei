var structVL6180xDevData__t =
[
    [ "Part2PartAmbNVM", "structVL6180xDevData__t.html#a267a0beadc11a2ba6718b575ab0454f1", null ],
    [ "XTalkCompRate_KCps", "structVL6180xDevData__t.html#a1d12b4951f0ecdda7448becad300f245", null ],
    [ "EceFactorM", "structVL6180xDevData__t.html#a1a30d071a4dc21efaee56ef60fb5dfd8", null ],
    [ "EceFactorD", "structVL6180xDevData__t.html#aa9886f44414ad73f84cda16ceb593c32", null ],
    [ "RangeIgnore", "structVL6180xDevData__t.html#a5f7e24c08e5f1bdc5f5448962e7426c9", null ],
    [ "IntegrationPeriod", "structVL6180xDevData__t.html#a6e3d65e3d6212261d3ccd3900e75918e", null ],
    [ "AlsGainCode", "structVL6180xDevData__t.html#a7a2514473384038c91fbc6414e2a5e3b", null ],
    [ "AlsScaler", "structVL6180xDevData__t.html#a0fc512b058c86f9d64562770c16aaa4f", null ],
    [ "UpscaleFactor", "structVL6180xDevData__t.html#a5a6137bd8c866e3abfb03ac3f241e5d2", null ],
    [ "WrapAroundFilterActive", "structVL6180xDevData__t.html#a83d931e2e6d3e23fea32f5ac89e74f8b", null ],
    [ "FilterData", "structVL6180xDevData__t.html#a938a9d8f40d24b05e4d0b6305023e95b", null ],
    [ "DMaxData", "structVL6180xDevData__t.html#a6be822d09f24bcc814c82e8c0f7af2eb", null ],
    [ "DMaxEnable", "structVL6180xDevData__t.html#a5571954b381827e0fa53d5fee3b40d98", null ],
    [ "Part2PartOffsetNVM", "structVL6180xDevData__t.html#a005a57232e065f42e65862e2bb5676ca", null ]
];