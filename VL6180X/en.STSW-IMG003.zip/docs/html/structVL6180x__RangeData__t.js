var structVL6180x__RangeData__t =
[
    [ "range_mm", "structVL6180x__RangeData__t.html#aa2f8cec7fb34d0bbe9c5cb27e0c65cf5", null ],
    [ "signalRate_mcps", "structVL6180x__RangeData__t.html#a15dab98a2ff42146f8037bb3fc801ea3", null ],
    [ "errorStatus", "structVL6180x__RangeData__t.html#a16a4552c0dd79371572269c291dc368d", null ],
    [ "rtnAmbRate", "structVL6180x__RangeData__t.html#addd11be6413d7e326a14be8232d29a04", null ],
    [ "rtnRate", "structVL6180x__RangeData__t.html#a9cc832e86049c30d4adb7694965874f6", null ],
    [ "rtnConvTime", "structVL6180x__RangeData__t.html#af759f966fadee780722af138ef2e31f3", null ],
    [ "refConvTime", "structVL6180x__RangeData__t.html#a14d6c3d78628ce04c5b61ce4fb96705b", null ],
    [ "DMax", "structVL6180x__RangeData__t.html#a6d5020ae3ad1420eb8b05c4528a0206e", null ],
    [ "FilteredData", "structVL6180x__RangeData__t.html#a56cc9ce0803cdbe346d62ac6e1c54288", null ]
];