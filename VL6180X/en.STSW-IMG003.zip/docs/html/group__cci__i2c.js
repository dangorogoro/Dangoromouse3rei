var group__cci__i2c =
[
    [ "VL6180x_I2C_USER_VAR", "group__cci__i2c.html#ga4f2e8b8e501d663f7887bcc42a7c7654", null ],
    [ "VL6180x_GetI2CAccess", "group__cci__i2c.html#gaf1a2db625f622c543ecc49eb92c5819f", null ],
    [ "VL6180x_DoneI2CAcces", "group__cci__i2c.html#ga6b32a86405d4360887f5c12464678db2", null ],
    [ "VL6180x_I2CWrite", "group__cci__i2c.html#gaf7ca271e54387b7aaf3aa12f1285b599", null ],
    [ "VL6180x_I2CRead", "group__cci__i2c.html#gadfb6ffdcbb765cf04d0d7796dc1869b1", null ],
    [ "VL6180x_GetI2CAccess", "group__cci__i2c.html#gafef2513f58c02dd80c9af0028a5d28a6", null ],
    [ "VL6180x_DoneI2CAccess", "group__cci__i2c.html#ga6864a2b926e26ed17dddd32ce48f1d16", null ],
    [ "VL6180x_GetI2cBuffer", "group__cci__i2c.html#ga646929ebcf5a88b366879adde11f1283", null ]
];