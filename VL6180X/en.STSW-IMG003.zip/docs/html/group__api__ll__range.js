var group__api__ll__range =
[
    [ "VL6180x_RangeIsFilteredMeasurement", "group__api__ll__range.html#gaf7f6a546e111cca74cc8ef1f51abb43d", null ],
    [ "VL6180x_RangeWaitDeviceReady", "group__api__ll__range.html#ga9289cfcc04f6d387fd3cb72a99788381", null ],
    [ "VL6180x_RangeSetInterMeasPeriod", "group__api__ll__range.html#gaa99ef0802f54b4f16a7e0d2f0998f5a5", null ],
    [ "VL6180x_UpscaleSetScaling", "group__api__ll__range.html#gaa0a6f68b3332860de910fff889474417", null ],
    [ "VL6180x_UpscaleGetScaling", "group__api__ll__range.html#gac15c32035ca4ca91e7478413d5a155d2", null ],
    [ "VL6180x_GetUpperLimit", "group__api__ll__range.html#ga903dca01e07a2ac6de808ad2ee9125b0", null ],
    [ "VL6180x_RangeSetThresholds", "group__api__ll__range.html#gabe731a79598cbf5d04d1a036ad3e1811", null ],
    [ "VL6180x_RangeGetThresholds", "group__api__ll__range.html#ga5848e2dd2237e001c9f93b5958147ed9", null ],
    [ "VL6180x_RangeSetRawThresholds", "group__api__ll__range.html#ga345eb476f8925195c5863c958e75755a", null ],
    [ "VL6180x_RangeSetEceFactor", "group__api__ll__range.html#gae4939dc08f359e8f0ad4b72ae7826691", null ],
    [ "VL6180x_RangeSetEceState", "group__api__ll__range.html#gaa3b9987cb865522722bfeede4795be2e", null ],
    [ "VL6180x_FilterSetState", "group__api__ll__range.html#ga6718c44496a1bf3975b6c360e57256f4", null ],
    [ "VL6180x_FilterGetState", "group__api__ll__range.html#ga67c8b80c455b457da46104ac707f31a0", null ],
    [ "VL6180x_DMaxSetState", "group__api__ll__range.html#ga74f92bc0c1a147f2e69a78687d8b778d", null ],
    [ "VL6180x_DMaxGetState", "group__api__ll__range.html#gac8cb4b087176aefc4cdebf2583cfe5ac", null ],
    [ "VL6180x_RangeSetSystemMode", "group__api__ll__range.html#ga0da5a6c1212310ffa261bbe8873557cc", null ],
    [ "VL6180x_RangeIgnoreSetEnable", "group__api__ll__range.html#ga7e97933dc1a80797b3e99121b8344cdd", null ],
    [ "VL6180x_RangeIgnoreConfigure", "group__api__ll__range.html#gaeed381680fc19039c0df6e3dc9c36dbc", null ]
];