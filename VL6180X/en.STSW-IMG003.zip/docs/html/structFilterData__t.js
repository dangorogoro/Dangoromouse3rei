var structFilterData__t =
[
    [ "MeasurementIndex", "structFilterData__t.html#a8db844ce430cf7170a1a009911fa245d", null ],
    [ "MeasurementsSinceLastFlush", "structFilterData__t.html#a8bfcffc78e92535b9c81408e55d3671c", null ],
    [ "LastTrueRange", "structFilterData__t.html#a3e16d128d4ed0f85dc35fc9e32597e7b", null ],
    [ "LastReturnRates", "structFilterData__t.html#aefb60ac6172eab9ebf3c0fe204d09fe1", null ],
    [ "StdFilteredReads", "structFilterData__t.html#a77e3d66aa696a399cfee7402b4638d8e", null ],
    [ "Default_ZeroVal", "structFilterData__t.html#adafe835b1644ccd323e7d04126393d09", null ],
    [ "Default_VAVGVal", "structFilterData__t.html#ae1819669aeeac9610abb6588b72e8dbe", null ],
    [ "NoDelay_ZeroVal", "structFilterData__t.html#a264c231e14cc7b40ad15ab7af8426210", null ],
    [ "NoDelay_VAVGVal", "structFilterData__t.html#abf161dd5bd0acd0f867df93254047f39", null ],
    [ "Previous_VAVGDiff", "structFilterData__t.html#a1daca413b3c9123eebcb48df7e61d0ee", null ],
    [ "FilteringOnGoingConsecutiveStates", "structFilterData__t.html#a9651a338f47445b95f2b62e546f37223", null ],
    [ "filterError", "structFilterData__t.html#ae38bb296a2bed137680ffe96df6b3c89", null ]
];