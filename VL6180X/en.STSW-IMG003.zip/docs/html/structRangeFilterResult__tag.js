var structRangeFilterResult__tag =
[
    [ "range_mm", "structRangeFilterResult__tag.html#aa46eeae9f87304d16cac46370536504f", null ],
    [ "rawRange_mm", "structRangeFilterResult__tag.html#a5dd037eabb8d39eb8f20c31c0682905b", null ],
    [ "filterError", "structRangeFilterResult__tag.html#a159771bfb25108be64e015cb22d83b6e", null ]
];