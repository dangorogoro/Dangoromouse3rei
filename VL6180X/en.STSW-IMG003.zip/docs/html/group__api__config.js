var group__api__config =
[
    [ "VL6180x_UPSCALE_SUPPORT", "group__api__config.html#gaa172820be86cd158b845f08d3cf4a654", null ],
    [ "VL6180x_ALS_SUPPORT", "group__api__config.html#ga1f8a066a683fe19458fd0a948fe42444", null ],
    [ "VL6180x_HAVE_DMAX_RANGING", "group__api__config.html#gaf233fde81baeae42b9592f999162ab14", null ],
    [ "VL6180x_WRAP_AROUND_FILTER_SUPPORT", "group__api__config.html#ga54c0db2e281a9728b594ba7689a3b17d", null ],
    [ "VL6180x_EXTENDED_RANGE", "group__api__config.html#gaf0cff70724a1d8e69ba43920e78b9bd7", null ]
];