var group__api__platform =
[
    [ "VL6180x_DEV_DATA_ATTR", "group__api__platform.html#gad84d532f7195fa8760208a87fa1c57db", null ],
    [ "ROMABLE_DATA", "group__api__platform.html#ga9b53c31da9dc47654090c83ce1940ced", null ],
    [ "VL6180x_RANGE_STATUS_ERRSTRING", "group__api__platform.html#gaf505f4201864c5524c75422463af52fc", null ],
    [ "VL6180x_SINGLE_DEVICE_DRIVER", "group__api__platform.html#ga76d85fb877db9297b9046d5c1c483dee", null ],
    [ "VL6180X_SAFE_POLLING_ENTER", "group__api__platform.html#ga7a7222b4b974eb7c307424580b03a66c", null ],
    [ "VL6180X_LOG_ENABLE", "group__api__platform.html#gacdc85ab9b0b7482787d38653f545e44b", null ],
    [ "VL6180x_PollDelay", "group__api__platform.html#gad050acd54e12734d963a98407c34bdb3", null ],
    [ "LOG_FUNCTION_START", "group__api__platform.html#ga8c37e10f958529ddbd8f836d3a8af2fe", null ],
    [ "LOG_FUNCTION_END", "group__api__platform.html#ga089d5551c4e26508a00c7dc4a09627d6", null ],
    [ "LOG_FUNCTION_END_FMT", "group__api__platform.html#ga263be57e18d8776ccceaef20aa05e6b2", null ],
    [ "VL6180x_ErrLog", "group__api__platform.html#gae6aea319d6b1fa9de0200f1d12b0fb26", null ],
    [ "VL6180x_HAVE_MULTI_READ", "group__api__platform.html#ga71f21f299ba1fcba3f46638ecaedd3e9", null ],
    [ "VL6180x_CACHED_REG", "group__api__platform.html#ga7761212711126dc4edb11f86cf53c2ca", null ],
    [ "trace_printf", "group__api__platform.html#ga9af5de14feeb990846c26f099ac0cd3e", null ],
    [ "LOG_GET_TIME", "group__api__platform.html#ga4da936b3eccd2eeb55772a967523a033", null ],
    [ "VL6180xDev_t", "group__api__platform.html#gaec46b1bc008d575d28bec1c252c5b1dd", null ],
    [ "VL6180x_PollDelay", "group__api__platform.html#ga257a40defbd7f9225171356af79e7101", null ],
    [ "log_file", "group__api__platform.html#gab936051f5aaca44c6c3c41dee0d19c36", null ]
];