var group__api__ll__als =
[
    [ "VL6180x_AlsWaitDeviceReady", "group__api__ll__als.html#gac9017a93c95d650c2be2b1eefb0393a5", null ],
    [ "VL6180x_AlsSetSystemMode", "group__api__ll__als.html#ga9a3f63f94e8dc21693ed86e3cb7d4f8e", null ]
];