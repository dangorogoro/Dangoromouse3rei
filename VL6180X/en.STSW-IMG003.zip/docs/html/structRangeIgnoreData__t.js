var structRangeIgnoreData__t =
[
    [ "ValidHeight", "structRangeIgnoreData__t.html#aed787c2501eef3730965c4b18df8fce6", null ],
    [ "IgnoreThreshold", "structRangeIgnoreData__t.html#a0b9ecef128e23e2375a05992ee7ee937", null ],
    [ "Enabled", "structRangeIgnoreData__t.html#a4c0a42f0e93ad8e407fdca7eb4c7984b", null ]
];