var group__api__ll__misc =
[
    [ "msec_2_i2cloop", "group__api__ll__misc.html#ga948708b20da7f5011a1f485668c90db6", null ],
    [ "VL6180x_SetGroupParamHold", "group__api__ll__misc.html#ga339f47e0340c94c218e09c07130a4b30", null ],
    [ "VL6180x_SetI2CAddress", "group__api__ll__misc.html#ga1586a0b8d1ab882c104f55244e1f0c6f", null ],
    [ "VL6180x_SetupGPIOx", "group__api__ll__misc.html#gab208e2c762e7bce613330e357eb6474f", null ],
    [ "VL6180x_SetGPIOxPolarity", "group__api__ll__misc.html#gabe147e2e4c6fc51960d2ed43c251d602", null ],
    [ "VL6180x_SetGPIOxFunctionality", "group__api__ll__misc.html#ga52b77acbc37458d95e3aa9d815832857", null ],
    [ "VL6180x_DisableGPIOxOut", "group__api__ll__misc.html#gad512cae30ab4534dded2ac4cf8067fc9", null ]
];