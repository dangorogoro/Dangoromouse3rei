var annotated_dup =
[
    [ "DMaxData_t", "structDMaxData__t.html", "structDMaxData__t" ],
    [ "FilterData_t", "structFilterData__t.html", "structFilterData__t" ],
    [ "IntrStatus_u", "unionIntrStatus__u.html", "unionIntrStatus__u" ],
    [ "RangeFilterResult_tag", "structRangeFilterResult__tag.html", "structRangeFilterResult__tag" ],
    [ "RangeIgnoreData_t", "structRangeIgnoreData__t.html", "structRangeIgnoreData__t" ],
    [ "VL6180x_AlsData_st", "structVL6180x__AlsData__st.html", "structVL6180x__AlsData__st" ],
    [ "VL6180x_RangeData_t", "structVL6180x__RangeData__t.html", "structVL6180x__RangeData__t" ],
    [ "VL6180xDevData_t", "structVL6180xDevData__t.html", "structVL6180xDevData__t" ]
];